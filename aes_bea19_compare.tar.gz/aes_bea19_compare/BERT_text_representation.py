import os
import os.path
import pandas as pd
from io import StringIO
import io

import numpy as np
from numpy import array
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder

SEQUENCE_LENGTH = 40
SEQUENCE_LENGTH_D = 25

#read train and val data
# fpath = 'data/TOEFL'
fpath = 'data/TOEFL_len_test'

from nltk import sent_tokenize
from bert_serving.client import BertClient
bc = BertClient()

max_num_sent = [32, 38, 41, 43, 38, 44, 35, 45]

for cur_prompt in range(1, 9):
# cur_prompt = 1
    for cur_cv in range(0, 5):

        # cur_prompt = "P" + str(i)

        # SEQUENCE_LEN = SEQUENCE_LENGTH
        # SEQUENCE_LEN = 50
        SEQUENCE_LEN = 40
        # SEQUENCE_LEN_D = SEQUENCE_LENGTH_D
        SEQUENCE_LEN_D = 25
        # SEQUENCE_LEN_D = max_num_sent[cur_prompt-1]

        df_train = pd.read_csv(os.path.join(fpath, 'train' + '_fold_' + str(cur_cv) +'.csv'))
        df_train = df_train.loc[df_train['prompt'] == cur_prompt]

        df_valid = pd.read_csv(os.path.join(fpath, 'valid' + '_fold_' + str(cur_cv) +'.csv'))
        df_valid = df_valid.loc[df_valid['prompt'] == cur_prompt]
        # text = df_train['essay']
        df_test = pd.read_csv(os.path.join(fpath,'test' + '_fold_' + str(cur_cv) +'.csv'))
        df_test = df_test.loc[df_test['prompt'] == cur_prompt]

        print(len(df_train))

        # text_val = df_val['text1']
        # text_train = df_train['text1']
        # rank_val = df_val['label']
        # rank_train = df_train['label']

        text_test = df_test['essay']
        text_train = df_train['essay']
        rank_test = df_test['essay_score']
        rank_valid = df_valid['essay_score']
        rank_train = df_train['essay_score']


        target_train = np.array(rank_train)
        target_valid = np.array(rank_valid)
        target_test = np.array(rank_test)

        onehot_encoder = OneHotEncoder(sparse=False)

        integer_encoded = target_train.reshape(len(target_train), 1)
        y_train = onehot_encoder.fit_transform(integer_encoded)

        integer_encoded = target_valid.reshape(len(target_valid), 1)
        y_valid = onehot_encoder.fit_transform(integer_encoded)

        integer_encoded_test = target_test.reshape(len(target_test), 1)
        y_test = onehot_encoder.fit_transform(integer_encoded_test)

        ### Get bert senence mebeddings for each sentence in an essay
        ## Based on BERT serving client https://pypi.org/project/bert-serving-client/
        ## base uncased model
        ## Pooling = NONE for token level representation
        ## bert-serving-start -model_dir /temp/uncased_L-12_H-768_A-12/ -num_worker=4 -pooling_strategy=NONE -max_seq_len=40
        
        print('Starting BERT client..')
        b_len = 768 
        X_train = []

        # for i in df_train['text1']:
        for i in df_train['essay']:
            i = sent_tokenize(i)
            X_train.extend(bc.encode(i[:SEQUENCE_LEN_D]))
            # encoded = bc.encode(i[:SEQUENCE_LEN_D])
            # print(encoded.shape)
            # [X_train.append(k) for i in encoded for k in i for j in k]
            # X_train.extend([e for sl in encoded for e in sl])
            for k in range(max(SEQUENCE_LEN_D - (len(i)), 0)):
                X_train.append([[0]*b_len]*SEQUENCE_LEN) # pad token maps to 0
        X_train = np.array(X_train)  

        np.save(fpath + '/X_train_TOEFL' + '_' + str(cur_cv) + '_' + str(cur_prompt), X_train)
        np.save(fpath + '/y_train_TOEFL' + '_' + str(cur_cv) + '_' + str(cur_prompt), y_train)

        print(X_train.shape)


        del X_train
        del y_train
        import gc
        gc.collect()

        #test set
        X_valid = []

        for i in df_valid['essay']:
            i = sent_tokenize(i)
            X_valid.extend(bc.encode(i[:SEQUENCE_LEN_D]))
            
            for k in range(max(SEQUENCE_LEN_D - (len(i)), 0)):
                X_valid.append([[0]*b_len]*SEQUENCE_LEN) # pad token maps to 0
        X_valid = np.array(X_valid)

        print(X_valid.shape)

        np.save(fpath + '/X_valid_TOEFL' + '_' + str(cur_cv) + '_' + str(cur_prompt), X_valid)
        np.save(fpath + '/y_valid_TOEFL' + '_' + str(cur_cv) + '_' + str(cur_prompt), y_valid)



        #test set
        X_test = []

        for i in df_test['essay']:
            i = sent_tokenize(i)
            X_test.extend(bc.encode(i[:SEQUENCE_LEN_D]))
            # encoded = bc.encode(i[:SEQUENCE_LEN_D])
            # [X_test.append(k) for i in encoded for k in i for j in k]
            # X_test.extend([e for sl in encoded for e in sl])
            for k in range(max(SEQUENCE_LEN_D - (len(i)), 0)):
                X_test.append([[0]*b_len]*SEQUENCE_LEN) # pad token maps to 0
        X_test = np.array(X_test)

        print(X_test.shape)


        np.save(fpath + '/X_test_TOEFL' + '_' + str(cur_cv) + '_' + str(cur_prompt), X_test)
        np.save(fpath + '/y_test_TOEFL' + '_' + str(cur_cv) + '_' + str(cur_prompt), y_test)
    # end for


