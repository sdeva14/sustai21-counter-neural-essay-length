#!/usr/bin/env bash

module load CUDA/9.0.176
module load GCC/7.3.0-2.30
module load cuDNN/7.0.5-CUDA-9.0.176
source ~/anaconda3/bin/activate tf_test

target_prompt=$1
cv_attempts=$2

#for fold in {0..4}
#do
#   python ~/workspace/cohe1/main.py --cur_fold $fold --essay_prompt_id_train $source_domain --essay_prompt_id_test $target_domain
    
#done
#python main_cv.py --essay_prompt_id_train $source_domain --essay_prompt_id_test $target_domain --target_model $model --cur_fold $cur_fold --encoder_type $encoder_type --cv_attempts $cv_attempts
python BERT_BCA_train_modified.py --target_prompt $target_prompt --cv_attempts $cv_attempts
